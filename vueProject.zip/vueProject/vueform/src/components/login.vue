<template>
  <div class="col-12 w-50 m-auto">
        <form v-bind:class="{'d-none':!data.showLogin}" id="login" method="get" action="/" @submit="loginuser" >
            <div> Login </div>
            <div class="input-form">
                <div class="input-label-form my-3">
                    <input class="form-control" placeholder="Username" v-model="logname" name="logname" id="logname"/>
                </div>
                <div class="input-label-form my-3">
                    <input class="form-control" placeholder="Password" v-model="logpass" name="logpass" id="logpass"/>
                </div>
            </div>
            <div v-bind:class="{'d-none':!loginError}" class="alert alert-danger"> {{loginErrorMsg}} </div>
            <button class="btn-primary text-center mouse_pointer" value="submit" type="submit"> Login </button>
            <hr/>
            <div class="small mouse_pointer"  v-on:click="goToRegis"    > Don't have Login? Register instead.</div>
        </form>

        <div v-bind:class="{'d-none':!showHash}"  class="alert alert-success"> Login successfully ! We have generated your hash code: {{hashValue}}</div>
    </div>
</template>

<script>
import axios from 'axios';
export default {
  name: 'Login',
  props: ["data"],
  methods: {
      loginuser(e){
          e.preventDefault();
          if ( this.logname && this.logpass){
    var logindata = {name: this.logname,  pass: this.logpass }
        axios
      .post('http://localhost:3000/login', {data: logindata} , {'header' : 'application/json'})
      .then(response => {
          if (response){
        if (response.data.status == 1){
            this.loginError = false;
            this.showHash = true;
            this.hashValue = response.data.result.hash;
            this.$emit('loadHashLogin',1)
        }else{
            this.loginError = true;
            this.showHash = false;
            this.loginErrorMsg = response.data.msg;
        }
        }else{
            this.loginError = true;
            this.showHash = false;
            this.loginErrorMsg = 'Please try again';
        }
      })
      }else{
          this.loginError = true;
            this.showHash = false;
          this.loginErrorMsg = 'Please enter valid data to proceed';
          }
          },
          goToRegis(){

            this.showHash = false;
        this.hashValue = '';
              this.$emit('goToRegis',1)
              }
      },
      data(){
          return{
            loginError: false,
            loginErrorMsg: '',
            showHash: false,
            hashValue: '',
            logpass: null,
            logname: null
          
        }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
.mouse_pointer{
    cursor: pointer;
    }
</style>
