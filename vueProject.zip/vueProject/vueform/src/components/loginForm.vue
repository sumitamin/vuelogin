<template>
  <div class="container mt-5">
        <div> Welcome! Please provide details to continue</div>
        
        <Register v-bind:data="data" v-on:goToLogin="loginNow" v-on:loadHashRegis="hashRegis"  />
        <Login v-bind:data="data" v-on:goToRegis="regisNow"  v-on:loadHashLogin="hashRegis" />
        <CheckToken v-bind:data="data"  />
        
    </div>
</template>

<script>
import Login from './login.vue';
import Register from './register.vue';
import CheckToken from './checkToken.vue';
export default {
  name: 'LoginForm',
  components: {
    Login,
    Register,
    CheckToken
  },
  methods:{
loginNow(){
    this.data.showLogin = true
     this.data.showRegister = false
     this.data.showCheckToken = false
     this.data.showHash = false
    },
    regisNow(){
    this.data.showLogin = false,
     this.data.showRegister = true
     this.data.showCheckToken = false
     this.data.showHash = false
    },
    hashRegis(){
        this.data.showCheckToken = true
    }
      },
  data(){
      return{
        data:{
        showRegister: true,
        showLogin: false,
        showCheckToken: false,
        showHash: false
        }
      }
}
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
