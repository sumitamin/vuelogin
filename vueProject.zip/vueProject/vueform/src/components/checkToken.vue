<template>
  <div class="col-12 w-50 m-auto" v-bind:class="{'d-none': !data.showCheckToken}">
        <form id="tokenForm" method="get" action="/" @submit="checktoken" >
            <div> Check token of user </div>
            <div class="input-form">
                <div class="input-label-form my-3">
                    <input class="form-control" placeholder="Enter Your Token" v-model="token" name="token" id="token"/>
                    
                </div>

                <div class="usernameHash" v-bind:class="{'d-none':!showHashName}"> username: {{hashname}}</div>
            </div>
            <div v-bind:class="{'d-none':!hashError}" class="alert alert-danger" > {{hashErrorMsg}} </div>
            <button class="btn-primary text-center" value="submit" type="submit"> Check User Data </button>
        </form>
    </div>
</template>

<script>
import axios from 'axios';
export default {
    
  name: 'CheckToken',
  props: ["data"],
  methods:{
        checktoken(e){
            e.preventDefault(); 

            if ( this.token){
    var tokendata = {token: this.token }
        axios
      .post('http://localhost:3000/checkToken', {data: tokendata} , {'header' : 'application/json'})
      .then(response => {
       this.hashname = response.data.status
      if (response.data.status == 1){
        this.hashError = false;
        this.hashname = response.data.result.name
        this.showHashName = true
      }else{
        this.hashError = true;
        this.hashErrorMsg = 'Please try again';
      }
      })
      }else{
          this.hashError = true;
          this.hashErrorMsg = 'Please enter valid token to proceed';
          }
        }
    },
data(){
    return{
        hashError: false,
        hashErrorMsg: '',
        token:null,
        hashname:'',
        showHashName:false
        }
    }
}


</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
