<template>
  <div class="col-12 w-50 m-auto">
        <form  id="register" v-bind:class="{'d-none':!data.showRegister}" method="get" action="/" @submit="getRegister">
            <div> Register </div>
            <div class="input-form">
                <div class="input-label-form my-3">
                    <input class="form-control" v-model="regname"  placeholder="Username" name="regname" id="regname"/>
                </div>
                <div class="input-label-form my-3">
                    <input class="form-control" v-model="regpass" placeholder="Password" name="regpass" id="regpass"/>
                </div>
            </div>
            <div v-bind:class="{'d-none':!registerError}" class="alert alert-danger">{{registerErrorMsg}} </div>
            <button class="btn-primary text-center mouse_pointer" value="submit" type="submit"> Register </button>
            <hr/>
            <div class="small mouse_pointer" v-on:click="goToLogin"> Already Have Login? Login Now.</div>
        </form>
         <div v-bind:class="{'d-none':!showHash}" class="alert alert-success">We have generated your hash code: {{hashValue}}</div>
    </div>
</template>

<script>
import axios from 'axios';
export default {
  name: 'Register',
  props: ["data"],
  data() {
      return{
    regname: null,
    regpass: null,
    registerErrorMsg: '',
    registerError: false,
    showHash: false,
    hashValue: ''
    }
  },
  methods:{
      
    getRegister(e){
       
e.preventDefault()
   if ( this.regname && this.regpass){
    var registerdata = {name: this.regname,  pass: this.regpass }
        axios
      .post('http://localhost:3000/register', {data: registerdata} , {'header' : 'application/json'})
      .then(response => {
      if (response.data.result.hash){
        this.registerError = false;
        this.showHash = true;
        this.hashValue = response.data.result.hash;
        this.$emit('loadHashRegis',1)

      }else{
        this.registerError = true;
        this.registerErrorMsg = 'Please try again';
      }
      })
      }else{
          this.registerError = true;
          this.registerErrorMsg = 'Please enter valid data to proceed';
          }
          
        },
        goToLogin(){
        this.showHash = false;
        this.hashValue = '';
        this.$emit('goToLogin',1);
        }  
      }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
.mouse_pointer{
    cursor: pointer;
    }
</style>
