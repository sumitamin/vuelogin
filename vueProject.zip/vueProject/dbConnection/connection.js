const mongoose = require('mongoose');

mongoose.connect(
     //'mongodb+srv://sumit:Thacarter4@cluster0-tujst.mongodb.net/test?retryWrites=true&w=majority',
     'mongodb+srv://sumit:Thacarter4@cluster0-tujst.mongodb.net/test?retryWrites=true&w=majority',
     //'mongodb+srv://sumit:Thacarter4@wreckage-q8z4p.mongodb.net/test?retryWrites=true&w=majority',
     //'mongodb://sumit:Thacarter4@main-shard-00-00-03xkr.mongodb.net:27017,main-shard-00-01-03xkr.mongodb.net:27017,main-shard-00-02-03xkr.mongodb.net:27017/main?ssl=true&replicaSet=Main-shard-0&authSource=admin&retryWrites=true',
     //'mongodb://sumit:Thacarter4@wreckage-shard-00-00-q8z4p.mongodb.net:27017,wreckage-shard-00-01-q8z4p.mongodb.net:27017,wreckage-shard-00-02-q8z4p.mongodb.net:27017/test?ssl=true&replicaSet=wreckage-shard-0&authSource=admin&retryWrites=true&w=majority',
{useNewUrlParser:true, useUnifiedTopology:true}
,(err, res)=>{
    if (!err)
    console.log('mongoose connected')
    else
    console.log('Could not connect to mongoose', err)
})

var con = new mongoose.Schema({ name: 'string', pass: 'string' , hash: 'string' });
var db = mongoose.model('loginForm', con);

module.exports = db;