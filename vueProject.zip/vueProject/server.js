const express = require('express');
const cors = require('cors');
const bcrypt = require('bcrypt');
const db = require('./dbConnection/connection.js');
const app = express();

app.use(express.json())
app.use(express.urlencoded({urlencoded:true}))
app.use(cors());
app.get('/', ()=>{
    console.log('Server is working')
})

app.post('/register', (req, res) => {
    var password = req.body.data.pass;
    var username = req.body.data.name;
    bcrypt.genSalt(10,(err, salt) => {
        bcrypt.hash(password, salt, (err, response) => {
            db.insertMany([{ name:username, pass:password, hash:response }],(err, result)=>{
                if (err){
                    res.json({status:0, msg: 'Something went wrong', result: 0}) 
                }else{
                    res.json({status:1, msg: 'success', result: result[0]} ) 
                }
            })
        } )
    }
    )
})
// username: username, password: password
app.post('/login', (req, res) => {
    console.log('node login', req.body)
    db.find({name: req.body.data.name, pass:req.body.data.pass},(err, result)=>{
        console.log('found', err, result, result.length)
        if (err){
            res.json({status:0, msg: 'Something went wrong', result: 0}) 
        }else if(result.length > 0){
            res.json({status:1, msg: 'success', result: result[0]})
        }
        else{
            res.json({status:0, msg: 'User Not Found', result: 0})
        }
    })
})

app.post('/checkToken', (req, res) => {
    db.find({hash: req.body.data.token},(err, result)=>{        
        if (err){
            res.json({status:0, msg: 'Something went wrong', result: 0})
            
        }else{
            res.send({status:1, msg: 'success', result: result[0]})
        }
    })
})



app.listen('3000', () => {
    console.log('server started on 3000');
});
